"""One-time E02 authoring: do not run reserve inference or rasterization here."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

import pymupdf

from scripts.symbol_benchmark_evaluator import PROTOCOL
from tests.symbol_benchmark_fixtures import (
    FAMILIES, FIXTURE_ROOT, ROOT, build_corpus, portable_reference, sha256, source_sha256,
)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def reserve_bytes():
    # Independently authored graphs, not transformations of public _segments().
    documents, occurrences, files = [], [], {}
    specifications = [
        ("reserve-author-01", "ATERRAMENTO", "family-f02-19", (50, 60), "ground-ring"),
        ("reserve-author-01", "TRANSFORMADOR", "family-f02-18", (190, 150), "three-lobes"),
        ("reserve-author-02", "PARA_RAIOS_MT", "family-f02-21", (50, 70), "zigzag-housing"),
        ("reserve-author-02", "ESTAI_MT", "family-f02-14", (170, 200), "anchor-bracket"),
    ]
    for document_id in ("reserve-author-01", "reserve-author-02"):
        document = pymupdf.open()
        page = document.new_page(width=400, height=300)
        for _, class_id, family, (x, y), kind in (s for s in specifications if s[0] == document_id):
            if kind == "ground-ring":
                page.draw_circle((x, y), 8, width=0.6)
                page.draw_line((x, y + 8), (x, y + 27), width=0.6)
                for offset, width in ((27, 11), (32, 7), (37, 3)):
                    page.draw_line((x-width, y+offset), (x+width, y+offset), width=0.6)
                bbox = [x-11, y-8, x+11, y+37]
            elif kind == "three-lobes":
                for cx, cy in ((x, y-8), (x-8, y+6), (x+8, y+6)):
                    page.draw_circle((cx, cy), 7, width=0.6)
                page.draw_line((x, y-15), (x, y-27), width=0.6)
                bbox = [x-15, y-27, x+15, y+13]
            elif kind == "zigzag-housing":
                page.draw_rect(pymupdf.Rect(x, y, x+13, y+30), width=0.6)
                page.draw_polyline([(x+6,y-8),(x+6,y+4),(x+2,y+10),(x+10,y+17),(x+4,y+24),(x+6,y+38)], width=0.6, closePath=False)
                bbox = [x, y-8, x+13, y+38]
            else:
                page.draw_line((x, y), (x+95, y-30), width=0.6)
                page.draw_polyline([(x+90,y-38),(x+99,y-30),(x+95,y-20)], width=0.6, closePath=False)
                page.draw_line((x+99,y-30),(x+107,y-32),width=0.6)
                bbox = [x, y-38, x+107, y]
            occurrences.append({
                "id": f"{document_id}-o{len(occurrences):02d}", "document_id": document_id,
                "page": 1, "layer": "base", "family": family, "class_id": class_id,
                "bbox": [bbox[0]/400,bbox[1]/300,bbox[2]/400,bbox[3]/300],
                "context": "operational", "evaluability": "confirmed", "situation": None,
                "quantity": None, "association": None, "strata": ["synthetic", "independent_drawing"],
                "notes": "Author-declared nominal semantic control, no normative-equivalence claim; visually unreviewed reserve until E16",
            })
        document.set_metadata({"producer":"Zeny E02 independent reserve v1"})
        payload = document.tobytes(garbage=4, deflate=True, no_new_id=True)
        document.close()
        path = document_id + ".pdf"
        files[path] = payload
        documents.append({"id":document_id,"sha256":hashlib.sha256(payload).hexdigest(),
            "path":path,"split":"reserve","ancestor_id":"reserve-author-graphs-v1",
            "template_family":"reserve-author-graphs-v1",
            "pages":[{"number":1,"width_pt":400,"height_pt":300}]})
    reference = {"schema_version":1,"families":list(FAMILIES),"documents":documents,"occurrences":occurrences}
    files["reference.json"] = encoded(reference)
    files["authoring-source.py"] = Path(__file__).read_bytes()
    files["README.txt"] = b"Operational seal only, no encryption. Do not list or open before E16. No inference, rendering or visual inspection performed in E02. Synthetic nominal controls do not prove normative conformance or field generalization.\n"
    return documents, files


FIXTURE_ROOT.mkdir(parents=True, exist_ok=True)
archive = FIXTURE_ROOT / "reserve.sealed.zip"
if archive.exists():
    raise SystemExit("Reserve already sealed; do not rewrite it")
partitions = []
for split in ("development", "calibration"):
    reference = portable_reference(build_corpus(ROOT / "tmp/e02-simbologia/b" / split, split=split))
    reference_file = FIXTURE_ROOT / f"reference-{split}.json"
    reference_file.write_bytes(encoded(reference))
    partitions.append({"split":split,"reference_path":reference_file.name,
                       "reference_sha256":sha256(reference_file),"documents":reference["documents"]})
documents, files = reserve_bytes()
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, payload in sorted(files.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, payload)
partitions.append({"split":"reserve","documents":documents})
manifest = {
    "schema_version":1,"corpus_id":"symbol-controls-e02-v1","seed":20260918,
    "randomness":"none; author coordinates and deterministic PDF/ZIP serialization",
    "generator_sha256":source_sha256(ROOT / "tests/symbol_benchmark_fixtures.py"),
    "generator_hash_normalization":"UTF-8 text with LF line endings",
    "reserve_authoring_sha256":source_sha256(Path(__file__)),
    "protocol_sha256":hashlib.sha256(encoded(PROTOCOL)).hexdigest(),
    "inventory_sha256":sha256(ROOT / "docs/data/inventario-simbologia-v1.json"),
    "pymupdf_version":pymupdf.VersionBind,
    "partitions":partitions,
    "reserve":{"path":archive.name,"sha256":sha256(archive),"bytes":archive.stat().st_size,
        "documents":len(documents),"pages":sum(len(doc["pages"]) for doc in documents),
        "evaluation_status":"sealed_until_E16","visual_review":"not_performed",
        "seal_type":"operational policy and SHA-256 integrity, not encryption",
        "limitations":"Small independent synthetic drawing set; not full inventory coverage or field validation"},
    "limitations":["Public PDFs are generated from author-owned source, not private examples.",
        "Families with no confirmed occurrences retain zero denominators.",
        "Drawing ancestry is grouped conservatively; rotations/raster/contexts never cross splits.",
        "Synthetic names designate author-intended semantic controls, not normative equivalence.",
        "Reserve was authored without renderer, detector or human/AI image review."]
}
(FIXTURE_ROOT / "manifest.json").write_bytes(encoded(manifest))
print(json.dumps({"reserve_sha256":manifest["reserve"]["sha256"],"reserve_documents":len(documents),
                  "reserve_pages":manifest["reserve"]["pages"],"generator_sha256":manifest["generator_sha256"]}))
